getwd()
setwd("C:\\Users\\ADMIN\\Desktop\\It24104353")

#Exercise
#1
#i
y <- rnorm(25, mean=45, sd = 2)

##ii
t.test(y, mu=46, alternative= "less")

